 <?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

// Main pages
Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/about', [PageController::class, 'about'])->name('about');
Route::get('/departments', [PageController::class, 'departments'])->name('departments');
Route::get('/services', [PageController::class, 'services'])->name('services');
Route::get('/doctors', [PageController::class, 'doctors'])->name('doctors');
Route::get('/contact', [PageController::class, 'contact'])->name('contact');
Route::post('/contact', [PageController::class, 'contactSubmit'])->name('contact.submit');

// Additional pages
Route::get('/appointment', [PageController::class, 'appointment'])->name('appointment');
Route::get('/department-details', [PageController::class, 'departmentDetails'])->name('department-details');
Route::get('/service-details', [PageController::class, 'serviceDetails'])->name('service-details');
Route::get('/testimonials', [PageController::class, 'testimonials'])->name('testimonials');
Route::get('/faq', [PageController::class, 'faq'])->name('faq');
Route::get('/gallery', [PageController::class, 'gallery'])->name('gallery');
Route::get('/terms', [PageController::class, 'terms'])->name('terms');
Route::get('/privacy', [PageController::class, 'privacy'])->name('privacy');
